<?php
/*
Plugin Name: CWS Portfolio & Staff
Plugin URI:  http://creaws.com
Description: Internal use for creaws/cwsthemes themes only.
Text Domain: cws-portfolio-staff
Version: 1.1.1
*/

/*------------------------------------
-------------- PORTFOLIO -------------
------------------------------------*/

$theme = wp_get_theme();
define('CWS_THEME_SLUG', $theme->get( 'TextDomain' ));

if ($theme->get( 'Template' )) {
  define('prospect', $theme->get( 'Template' ));
} else {
  define('prospect', $theme->get( 'TextDomain' ));
}

add_action( "init", "register_cws_portfolio_cat" );
add_action( "init", "register_cws_portfolio" );

/**
 * Load plugin textdomain.
 */
function cws_load_textdomain() {
  load_plugin_textdomain( 'cws-portfolio-staff', false, basename( dirname( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'cws_load_textdomain' );


function register_cws_portfolio_cat(){

 $portfolio_slug = get_slug('portfolio_slug');
 $portfolio_slug = empty( $portfolio_slug ) ? 'portfolio' : $portfolio_slug;
 register_taxonomy( 'cws_portfolio_cat', 'cws_portfolio', array(
  'hierarchical' => true,
  'show_admin_column' => true,
  'rewrite' => array( 'slug' => sanitize_title($portfolio_slug . '-cat') )
  ));
}

function get_slug($taxonomy) {
 return call_user_func_array(CWS_THEME_SLUG . '_get_option', array($taxonomy));
}

function register_cws_portfolio (){
 $labels = array(
  'name' => esc_html__( 'Portfolio items', 'cws-portfolio-staff' ),
  'singular_name' => esc_html__( 'Portfolio item', 'cws-portfolio-staff' ),
  'menu_name' => esc_html__( 'Portfolio', 'cws-portfolio-staff' ),
  'add_new' => esc_html__( 'Add Portfolio Item', 'cws-portfolio-staff' ),
  'add_new_item' => esc_html__( 'Add New Portfolio Item', 'cws-portfolio-staff' ),
  'edit_item' => esc_html__('Edit Portfolio Item', 'cws-portfolio-staff' ),
  'new_item' => esc_html__( 'New Portfolio Item', 'cws-portfolio-staff' ),
  'view_item' => esc_html__( 'View Portfolio Item', 'cws-portfolio-staff' ),
  'search_items' => esc_html__( 'Search Portfolio Item', 'cws-portfolio-staff' ),
  'not_found' => esc_html__( 'No Portfolio Items found', 'cws-portfolio-staff' ),
  'not_found_in_trash' => esc_html__( 'No Portfolio Items found in Trash', 'cws-portfolio-staff' ),
  'parent_item_colon' => '',
  );
 $portfolio_slug = get_slug( 'portfolio_slug' );
 $portfolio_slug = empty( $portfolio_slug ) ? 'portfolio' : $portfolio_slug;
 register_post_type( 'cws_portfolio', array(
  'label' => esc_html__( 'Portfolio items', 'cws-portfolio-staff' ),
  'labels' => $labels,
  'public' => true,
  'rewrite' => array( 'slug' => sanitize_title($portfolio_slug) ),
  'capability_type' => 'post',
  'supports' => array(
   'title',
   'editor',
   'excerpt',
   'page-attributes',
   'thumbnail'
   ),
  'menu_position' => 23,
  'menu_icon' => 'dashicons-format-gallery',
  'taxonomies' => array( 'cws_portfolio_cat' ),
  'has_archive' => true
 ));
}

/*------------------------------------
---------------- STAFF ---------------
------------------------------------*/

add_action( "init", "register_cws_staff_department" );
add_action( "init", "register_cws_staff_position" );
add_action( "init", "register_cws_staff" );

function register_cws_staff (){
 $labels = array(
  'name' => esc_html__( 'Staff members', 'cws-portfolio-staff' ),
  'singular_name' => esc_html__( 'Staff member', 'cws-portfolio-staff' ),
  'menu_name' => esc_html__( 'Our team', 'cws-portfolio-staff' ),
  'all_items' => esc_html__( 'All', 'cws-portfolio-staff' ),
  'add_new' => esc_html__( 'Add new', 'cws-portfolio-staff' ),
  'add_new_item' => esc_html__( 'Add New Staff Member', 'cws-portfolio-staff' ),
  'edit_item' => esc_html__('Edit Staff Member\'s info', 'cws-portfolio-staff' ),
  'new_item' => esc_html__( 'New Staff Member', 'cws-portfolio-staff' ),
  'view_item' => esc_html__( 'View Staff Member\'s info', 'cws-portfolio-staff' ),
  'search_items' => esc_html__( 'Find Staff Member', 'cws-portfolio-staff' ),
  'not_found' => esc_html__( 'No Staff Members found', 'cws-portfolio-staff' ),
  'not_found_in_trash' => esc_html__( 'No Staff Members found in Trash', 'cws-portfolio-staff' ),
  'parent_item_colon' => '',
  );
 $staff_slug = get_slug( 'staff_slug' );
 $staff_slug = empty( $staff_slug ) ? 'staff' : $staff_slug;
 register_post_type( 'cws_staff', array(
  'label' => esc_html__( 'Staff members', 'cws-portfolio-staff' ),
  'labels' => $labels,
  'public' => true,
  'rewrite' => array( 'slug' => sanitize_title($staff_slug) ),
  'capability_type' => 'post',
  'supports' => array(
   'title',
   'editor',
   'excerpt',
   'page-attributes',
   'thumbnail'
   ),
  'menu_position' => 24,
  'menu_icon' => 'dashicons-groups',
  'taxonomies' => array( 'cws_staff_member_position' ),
  'has_archive' => true
 ));
}

function register_cws_staff_department(){
 $staff_slug = get_slug( 'staff_slug' );
 $staff_slug = empty( $staff_slug ) ? 'staff' : $staff_slug;
 $labels = array(
  'name' => esc_html__( 'Departments', 'cws-portfolio-staff' ),
  'singular_name' => esc_html__( 'Staff department', 'cws-portfolio-staff' ),
  'all_items' => esc_html__( 'All Staff departments', 'cws-portfolio-staff' ),
  'edit_item' => esc_html__( 'Edit Staff department', 'cws-portfolio-staff' ),
  'view_item' => esc_html__( 'View Staff department', 'cws-portfolio-staff' ),
  'update_item' => esc_html__( 'Update Staff department', 'cws-portfolio-staff' ),
  'add_new_item' => esc_html__( 'Add Staff department', 'cws-portfolio-staff' ),
  'new_item_name' => esc_html__( 'New Staff department name', 'cws-portfolio-staff' ),
  'parent_item' => esc_html__( 'Parent Staff department', 'cws-portfolio-staff' ),
  'parent_item_colon' => esc_html__( 'Parent Staff department:', 'cws-portfolio-staff' ),
  'search_items' => esc_html__( 'Search Staff departments', 'cws-portfolio-staff' ),
  'popular_items' => esc_html__( 'Popular Staff departments', 'cws-portfolio-staff' ),
  'separate_items_width_commas' => esc_html__( 'Separate with commas', 'cws-portfolio-staff' ),
  'add_or_remove_items' => esc_html__( 'Add or Remove Staff departments', 'cws-portfolio-staff' ),
  'choose_from_most_used' => esc_html__( 'Choose from the most used Staff departments', 'cws-portfolio-staff' ),
  'not_found' => esc_html__( 'No Staff departments found', 'cws-portfolio-staff' )
 );
 register_taxonomy( 'cws_staff_member_department', 'cws_staff', array(
  'labels' => $labels,
  'hierarchical' => true,
  'show_admin_column' => true,
  'rewrite' => array( 'slug' => sanitize_title($staff_slug . '-cat') )
 ));
}

function register_cws_staff_position(){
 $staff_slug = get_slug( 'staff_slug' );
 $staff_slug = empty( $staff_slug ) ? 'staff' : $staff_slug;
 $labels = array(
  'name' => esc_html__( 'Positions', 'cws-portfolio-staff' ),
  'singular_name' => esc_html__( 'Staff Member position', 'cws-portfolio-staff' ),
  'all_items' => esc_html__( 'All Staff Member positions', 'cws-portfolio-staff' ),
  'edit_item' => esc_html__( 'Edit Staff Member position', 'cws-portfolio-staff' ),
  'view_item' => esc_html__( 'View Staff Member position', 'cws-portfolio-staff' ),
  'update_item' => esc_html__( 'Update Staff Member position', 'cws-portfolio-staff' ),
  'add_new_item' => esc_html__( 'Add Staff Member position', 'cws-portfolio-staff' ),
  'new_item_name' => esc_html__( 'New Staff Member position name', 'cws-portfolio-staff' ),
  'search_items' => esc_html__( 'Search Staff Member positions', 'cws-portfolio-staff' ),
  'popular_items' => esc_html__( 'Popular Staff Member positions', 'cws-portfolio-staff' ),
  'separate_items_width_commas' => esc_html__( 'Separate with commas', 'cws-portfolio-staff' ),
  'add_or_remove_items' => esc_html__( 'Add or Remove Staff Member positions', 'cws-portfolio-staff' ),
  'choose_from_most_used' => esc_html__( 'Choose from the most used Staff Member positions', 'cws-portfolio-staff' ),
  'not_found' => esc_html__( 'No Staff Member positions found', 'cws-portfolio-staff' )
 );
 register_taxonomy( 'cws_staff_member_position', 'cws_staff', array(
  'labels' => $labels,
  'show_admin_column' => true,
  'rewrite' => array( 'slug' => sanitize_title($staff_slug . '-tag') ),
  'show_tagcloud' => false
 ));
}

function add_order_column( $columns ) {
  $columns['menu_order'] = /*esc_html__( */"Order"/*, "prospect" )*/;
  return $columns;
}
add_action('manage_edit-cws_staff_columns', 'add_order_column');
add_action('manage_edit-cws_portfolio_columns', 'add_order_column');

/**
* show custom order column values
*/
function show_order_column($name){
  global $post;
  switch ($name) {
    case 'menu_order':
      $order = $post->menu_order;
      echo $order;
      break;
   default:
      break;
   }
}
add_action('manage_cws_staff_posts_custom_column','show_order_column');
add_action('manage_cws_portfolio_posts_custom_column','show_order_column');

/**
* make column sortable
*/
function order_column_register_sortable( $columns ){
	$new_columns = array(
		"menu_order" 	=> "menu_order",
		"date"			=> "date",
		"title"			=> "title"
	);
	return $new_columns;
}
add_filter('manage_edit-cws_staff_sortable_columns','order_column_register_sortable');
add_filter('manage_edit-cws_portfolio_sortable_columns','order_column_register_sortable');

?>