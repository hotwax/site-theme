<?php
/*
Plugin Name: Prospect Shortcodes
Plugin URI:  http://cwsthemes.com
Description: Internal use for CWSThemes only.
Version:     1.1.2
Author:      CWSThemes
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: prospect-shortcodes
*/
if ( !defined( 'PROSPECT_THEME_COLOR' ) ){
	define( 'PROSPECT_THEME_COLOR', '#e95f58' );
}

/**
 * Load plugin textdomain.
 */
function cws_load_shortc_textdomain() {
  load_plugin_textdomain( 'prospect-shortcodes', false, basename( dirname( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'cws_load_shortc_textdomain' );


//Add Widgets
add_action( "widgets_init", "cws_register_widgets" );
function cws_register_widgets() {

	require_once( 'widgets/prospect_widget_social.php' );
	require_once( 'widgets/prospect_widget_twitter.php' );
	require_once( 'widgets/prospect_widget_cws_staff.php' );
	require_once( 'widgets/prospect_widget_latest_posts.php' );
	require_once( 'widgets/prospect_widget_text.php' );

	register_widget( 'Prospect_Social_Widget' );
	register_widget( 'Prospect_Twitter_Widget' );
	register_widget( 'Prospect_CWS_Staff_Widget' );
	register_widget( 'Prospect_Latest_Posts' );
	register_widget( 'Prospect_Text_Widget' );

}

require_once( 'metaboxes.php' );


function prospect_msg_box ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		'type'					=> 'success',
		'title'					=> '',
		'text'					=> '',
		'is_closable'			=> '',
		'customize'				=> '',
		'with_icon'				=> '',
		'custom_icon'			=> '',
		'custom_fill_color'		=> PROSPECT_THEME_COLOR,
		'custom_font_color'		=> '#fff',
		'el_class'				=> ''
	), $atts));
	$out = "";
	$type = esc_html( $type );
	$is_closable = (bool)$is_closable;
	$customize = (bool)$customize;
	$with_icon = (bool)$with_icon;
	$custom_icon = esc_html( $custom_icon );
	$el_class = esc_attr( $el_class );
	$content = !empty( $text ) ? $text : $content;
	$section_id = uniqid( "prospect_msg_box_" );
	ob_start();
	if ( $customize ){
		echo !empty( $custom_fill_color ) ? "background-color: $custom_fill_color;" : "";
		echo !empty( $custom_font_color ) ? "color: $custom_font_color;" : "";
	}
	$section_styles = ob_get_clean();
	ob_start();
	if ( $customize ){
		echo !empty( $custom_font_color ) ? "background-color: $custom_font_color;" : "";
	}
	$icon_part_styles = ob_get_clean();	
	ob_start();
	if ( $customize ){
		echo !empty( $custom_fill_color ) ? "color: $custom_fill_color;" : "";
	}
	$icon_styles = ob_get_clean();
	$icon_class = "msg_icon";
	$icon_class .= $customize && !empty( $custom_icon ) ? " fa fa-{$custom_icon}" : "";
	if ( !empty( $title ) || !empty( $content ) ){
		$out .= "<div id='$section_id' class='prospect_msg_box prospect_module $type" . ( $is_closable ? " closable" : "" ) . ( $with_icon ? " with-icon" : "" ) . ( !empty( $el_class ) ? " $el_class" : "" ) . "'" . ( !empty( $section_styles ) ? " style='$section_styles'" : "" ) . ">";
			if ( $with_icon ) {
				$out .= "<div class='icon_part'" . ( !empty( $icon_part_styles ) ? " style='$icon_part_styles'" : "" ) . ">";
					$out .= "<i class='$icon_class'" . ( !empty( $icon_styles ) ? " style='$icon_styles'" : "" ) . "></i>";
				$out .= "</div>";
			}
			$out .= "<div class='content_part'>";
				$out .= !empty( $title ) ? "<div class='title'>$title</div>" : "";
				$out .= !empty( $content ) ? "<p>$content</p>" : "";
			$out .= "</div>";
			$out .= $is_closable ? "<a class='close_button'></a>" : "";
		$out .= "</div>";
	}
	return $out;
}
add_shortcode( 'cws_sc_msg_box', 'prospect_msg_box' );

function prospect_vc_posts_grid ( $atts = array(), $content = "" ){
	$defaults = array(
		'title'					=> '',
		'title_align'			=> 'left',
		'post_type'				=> '',
		'total_items_count'		=> '',
		'portfolio_style'		=> '',
		'display_style'			=> 'grid',
		'select_filter'			=> '',
		'carousel_pagination'	=> '',
		'items_pp'				=> esc_html( get_option( 'posts_per_page' ) ),
		'el_class'				=> '',
		'chars_count'			=> '200',
	);
	$proc_atts = shortcode_atts( $defaults, $atts );

	extract( $proc_atts );
	$out = "";
	$carousel_pagination = (bool)$carousel_pagination;
	$select_filter = (bool)$select_filter;
	if ( empty( $post_type ) ) return $out;
	$cws_portfolio_layout = isset( $atts['cws_portfolio_layout'] ) && !empty( $atts['cws_portfolio_layout'] ) ? $atts['cws_portfolio_layout'] : 'def';
	$cws_portfolio_show_data_override = isset( $atts['cws_portfolio_show_data_override'] ) && !empty( $atts['cws_portfolio_show_data_override'] ) ? $atts['cws_portfolio_show_data_override'] : false;
	$chars_count = isset( $atts['chars_count'] ) && !empty( $atts['chars_count'] ) ? $atts['chars_count'] : false;
	$cws_portfolio_data_to_show = isset( $atts['cws_portfolio_data_to_show'] ) && !empty( $atts['cws_portfolio_data_to_show'] ) ? $atts['cws_portfolio_data_to_show'] : "";
	$cws_staff_layout = isset( $atts['cws_staff_layout'] ) && !empty( $atts['cws_staff_layout'] ) ? $atts['cws_staff_layout'] : 'def';
	$cws_staff_hide_meta_override = isset( $atts['cws_staff_hide_meta_override'] ) && !empty( $atts['cws_staff_hide_meta_override'] ) ? $atts['cws_staff_hide_meta_override'] : false;
	$cws_staff_data_to_hide = isset( $atts['cws_staff_data_to_hide'] ) && !empty( $atts['cws_staff_data_to_hide'] ) ? $atts['cws_staff_data_to_hide'] : "";
	$tax = isset( $atts[$post_type . '_tax'] ) ? $atts[$post_type . '_tax'] : '';
	$terms = isset( $atts["{$post_type}_{$tax}_terms"] ) ? $atts["{$post_type}_{$tax}_terms"] : "";
	$proc_atts = array_merge( $proc_atts, array(
		'cws_portfolio_layout'					=> $cws_portfolio_layout,
		'cws_portfolio_show_data_override'		=> $cws_portfolio_show_data_override,
		'cws_portfolio_data_to_show'			=> $cws_portfolio_data_to_show,
		'cws_staff_layout'						=> $cws_staff_layout,
		'cws_staff_hide_meta_override'			=> $cws_staff_hide_meta_override,	
		'cws_staff_data_to_hide'				=> $cws_staff_data_to_hide,
		'chars_count'							=> $chars_count,
		'tax'									=> $tax,
		'terms'									=> $terms
	));
	$out .= function_exists( "prospect_posts_grid" ) ? prospect_posts_grid( $proc_atts ) : "";
	return $out;
}
add_shortcode( 'cws_sc_vc_posts_grid', 'prospect_vc_posts_grid' );
add_shortcode( 'cws_sc_posts_grid', 'prospect_posts_grid' );

function prospect_sc_vc_blog ( $atts = array(), $content = "" ){
	$post_type = "post";
	$def_blog_layout = prospect_get_option( 'def_blog_layout' );
	$def_blog_layout = isset( $def_blog_layout ) ? $def_blog_layout : "";
	$def_chars_count = prospect_get_option( 'def_blog_chars_count' );
	$def_chars_count = isset( $def_chars_count ) && is_numeric( $def_chars_count ) ? $def_chars_count : '200';
	$defaults = array(
		'title'						=> '',
		'title_align'				=> 'left',
		'total_items_count'			=> '',
		'layout'					=> $def_blog_layout,
		'post_hide_meta_override'	=> false,
		'post_hide_meta'			=> '',
		'chars_count'				=> $def_chars_count,
		'display_style'				=> 'grid',
		'items_pp'					=> esc_html( get_option( 'posts_per_page' ) ),
		'links_enable'				=> '',
		'single_img'				=> '',
		'el_class'					=> '',
	);
	$proc_atts = shortcode_atts( $defaults, $atts );
	extract( $proc_atts );
	$out = "";
	$tax = isset( $atts[$post_type . '_tax'] ) ? $atts[$post_type . '_tax'] : '';
	$terms = isset( $atts["{$post_type}_{$tax}_terms"] ) ? $atts["{$post_type}_{$tax}_terms"] : "";
	$proc_atts = array_merge( $proc_atts, array(
		'post_hide_meta_override'				=> $post_hide_meta_override,
		'post_hide_meta'						=> $post_hide_meta,
		'tax'									=> $tax,
		'terms'									=> $terms
	));
	$out .= function_exists( "prospect_sc_blog" ) ? prospect_sc_blog( $proc_atts ) : "";
	return $out;
}
add_shortcode( 'cws_sc_vc_blog', 'prospect_sc_vc_blog' );
add_shortcode( 'cws_sc_blog', 'prospect_sc_blog' );

function prospect_sc_icon ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"icon_lib"			=> "",
		"url"				=> "",
		"new_tab"			=> "",
		"title"				=> "",
		"type"				=> "figure",
		"icon_alt"			=> "",
		"size"				=> "lg",
		"aligning"			=> "",
		"add_hover"			=> "",
		"customize_colors"	=> "",
		"fill_color"		=> "#fff",
		"font_color"		=> PROSPECT_THEME_COLOR,
		"el_class"			=> ""
	), $atts));
	$out = "";
	$icon_lib 			= esc_attr( $icon_lib );
	$icon 				= prospect_vc_sc_get_icon( $atts );
	$icon 				= esc_attr( $icon );
	$url  				= esc_url( $url );
	$new_tab			= (bool)$new_tab;
	$icon_alt			= (bool)$icon_alt;
	$title 				= esc_html( $title );
	$type 				= esc_html( $type );
	$size				= esc_html( $size );
	$aligning			= esc_html( $aligning );
	$add_hover			= (bool)$add_hover;
	$customize_colors	= (bool)$customize_colors;
	$fill_color			= esc_html( $fill_color );
	$font_color			= esc_html( $font_color );
	$el_class			= esc_attr( $el_class );
	if ( empty( $icon ) ) return $out;
	if ( function_exists( 'vc_icon_element_fonts_enqueue' ) ){
		vc_icon_element_fonts_enqueue( $icon_lib );
	}
	$icon_id = uniqid( "prospect_icon_" );
	ob_start();	
	if ( $customize_colors && !empty( $fill_color ) && !empty( $font_color ) ){	
		echo "#$icon_id{";
			echo "color: $font_color;";
		echo "}";
		echo "#$icon_id svg{";
			echo "stroke: $font_color;";
		echo "}";
		echo "#$icon_id.icon_alt svg{";
			echo "fill: $fill_color;";
			echo "stroke: $fill_color;";
		echo "}";
		if ( $add_hover ){
			echo "#$icon_id.hovered:hover{";
				echo "color: $fill_color;";
			echo "}";
			echo "#$icon_id.hovered.icon_alt:hover svg{";
				echo "stroke: $font_color;";
			echo "}";				
		}
		if ( $add_hover ){
			echo "#$icon_id.hovered:hover svg{";
				echo "fill: $font_color;";
			echo "}";				
		}
		if ( $size == "fw_icon" ) {
			echo ".prospect_icon_wrapper {
				display: block;
				margin: 0;
			}";
		}
	}
	$styles = ob_get_clean();
	$styles = json_encode($styles);
	$al_class = !empty( $aligning ) ? "align{$aligning}" : "";
	$wrapper_tag = "div";
	$wrapper_classes = "prospect_icon_wrapper render_styles";
	$wrapper_classes .= !empty( $styles ) ? " $al_class" : "";
	$tag = !empty( $url ) ? "a" : "div";
	$wrapper_tag_atts = $wrapper_tag;
	$wrapper_tag_atts .= " data-style='".esc_attr($styles)."' class='$wrapper_classes'";
	$classes = "prospect_icon $icon $type fa-$size";
	$classes .= $add_hover ? " hovered" : "";
	$classes .= $icon_alt ? " icon_alt" : "";
	$classes .= empty( $styles ) ? " $al_class" : "";
	$classes .= !empty( $el_class ) ? " $el_class" : "";
	$tag_atts = $tag == 'a' ? "$tag href='$url'" : $tag;
	$tag_atts .= " id='$icon_id'";
	$tag_atts .= " class='$classes'";
	$tag_atts .= !empty( $url ) && $new_tab ? " target='_blank'" : "";
	$tag_atts .= !empty( $title ) ? " title='$title'" : "";
	$figure_type = ($type == 'figure') ? prospect_figure_style() : "";
	$out .= "<$wrapper_tag_atts>";
	$out .= "<$tag_atts>" . $figure_type . "</$tag>";
	$out .= "</$wrapper_tag>";
	return $out;
}
add_shortcode( 'cws_sc_icon', 'prospect_sc_icon' );

function prospect_sc_button ( $atts = array(), $content = "" ){
	$font_options = prospect_get_option( 'body_font' );
	$font_color = esc_attr( $font_options['color'] );
	extract( shortcode_atts( array(
		"title"				=> "",
		"url"				=> "",
		"new_tab"			=> "",
		"size"				=> "regular",
		"ofs"				=> "",
		"aligning"			=> "",
		"fw"				=> "",
		"icon"				=> "",
		"icon_pos"			=> "right",
		"alt"				=> "",
		"without_fill"		=> "",
		"customize_colors"	=> "",
		"custom_color"		=> PROSPECT_THEME_COLOR,
		"font_color"		=> $font_color,
		"el_class"			=> ""
	), $atts));
	$out = "";
	$title 				= esc_html( $title );
	$url  				= esc_url( $url );
	$new_tab			= (bool)$new_tab;
	$size 				= esc_html( $size );
	$ofs 				= (int)$ofs;
	$aligning			= esc_html( $aligning );
	$fw					= (bool)$fw;
	$icon				= esc_html( $icon );
	$alt				= (bool)$alt;
	$customize_colors	= (bool)$customize_colors;
	$without_fill		= (bool)$without_fill;
	$custom_color		= esc_attr( $custom_color );
	$font_color			= esc_attr( $font_color );
	$el_class			= esc_attr( $el_class );
	$button_id = uniqid( "prospect_button_" );
	
	/* styles */
	ob_start();
	if ( $ofs > 0 ){
		echo "#$button_id{";
			echo "padding-left: {$ofs}px;";
			echo "padding-right: {$ofs}px;";
		echo "}";
	}
	if ( $customize_colors ){
		echo "#$button_id{";
			if ( $alt ){
				echo !empty( $custom_color ) ? "background-color: $custom_color;" : "";
				echo "color: #fff;";
				echo !empty( $custom_color ) ? "border-color: $custom_color;" : "";
			}
			else{
				echo "background-color: transparent;";
				echo !empty( $font_color ) ? "color: $font_color;" : "";
				echo !empty( $custom_color ) ? "border-color: $custom_color;" : "";					
			}
		echo "}";
		echo "#$button_id:hover{";
		if ( $alt ){
			echo !empty( $font_color ) ? "color: $font_color;" : "";
			echo "background-color: transparent;";
			echo !empty( $custom_color ) ? "border-color: $custom_color;" : "";
			echo "}";	
		}
		else{
			echo !empty( $custom_color ) ? "background-color: $custom_color;" : "";
			echo "color: #fff;";
			echo empty( $custom_color ) ? "border-color: $custom_color;" : "";			
		echo "}";				
		}
	}
	$styles = ob_get_clean();
	$styles = json_encode($styles);

	/* \styles */

	$al_class = !empty( $aligning ) ? " align{$aligning}" : "";
	$wrapper_tag = "div";
	$wrapper_classes = "prospect_button_wrapper render_styles";
	$wrapper_classes .= !empty( $styles ) ? $al_class : "";
	$wrapper_tag_atts = $wrapper_tag;
	$wrapper_tag_atts .= !empty( $wrapper_classes ) ? " data-style='".esc_attr($styles)."' class='$wrapper_classes'" : "";

	$tag = "a";
	$tag_atts = !empty( $url ) ? "$tag href='$url'" : $tag;
	$tag_atts .= " id='$button_id'";
	$classes = "prospect_button $size";
	$classes .= $fw ? " fw" : "";
	$classes .= $alt ? " alt" : "";
	$classes .= $without_fill ? " without_fill" : "";
	$classes .= empty( $styles ) ? $al_class : "";
	$classes .= !empty( $el_class ) ? " $el_class" : "";
	$tag_atts .= " class='$classes'";
	$tag_atts .= !empty( $url ) && $new_tab ? " target='_blank'" : "";

	$out .= !empty( $styles ) ? "<$wrapper_tag_atts>" : "";
		// $out .= !empty( $styles ) ? "<style type='text/css'>$styles</style>" : "";
		$out .= "<$tag_atts>";
			if ( !empty( $icon ) && $icon_pos == 'left' ){
				$out .= "<i class='fa fa-$icon'></i>&#x20;";
			}
			$out .= $title;
			if ( !empty( $icon ) && $icon_pos == 'right' ){
				$out .= "&#x20;<i class='fa fa-$icon'></i>";
			}		
		$out .= "</$tag>";
	$out .= !empty( $styles ) ? "</$wrapper_tag>" : "";
	return $out;
}
add_shortcode( 'cws_sc_button', 'prospect_sc_button' );

function prospect_sc_dropcap ( $atts = array(), $content = "" ){
	return "<span class='dropcap'>$content</span>";
}
add_shortcode( 'cws_sc_dropcap', 'prospect_sc_dropcap' );

function prospect_sc_mark ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		'font_color'	=> '#fff',
		'bg_color'		=> PROSPECT_THEME_COLOR
	), $atts));
	return "<mark style='color: $font_color;background-color: $bg_color;'>$content</mark>";
}
add_shortcode( 'cws_sc_mark', 'prospect_sc_mark' );

function prospect_sc_embed ( $atts, $content ) {
	extract( shortcode_atts( array(
		'url' => '',
		'width' => '',
		'height' => ''
	), $atts));
	$url = esc_url( $url );
	return !empty( $url ) ? apply_filters( "the_content", "[embed" . ( !empty( $width ) && is_numeric( $width ) ? " width='$width'" : "" ) . ( !empty( $height ) && is_numeric( $height ) ? " height='$height'" : "" ) . "]" . $url . "[/embed]" ) : "";
}
add_shortcode( 'cws_sc_embed', 'prospect_sc_embed' );

function prospect_sc_banner ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"url"				=> "",
		"title"				=> "",
		"offer"				=> "",
		"icon"				=> "",
		"icon_pos"			=> "right",
		"customize_colors"	=> "",
		"bg_color"			=> PROSPECT_THEME_COLOR,
		"font_color"		=> PROSPECT_THEME_COLOR,
		"icon_color"		=> PROSPECT_THEME_COLOR,
		"use_bg_img"		=> "",
		"bg_img"			=> "",
		"bg_size"			=> "auto",
		"bg_repeat"			=> "repeat",
		"bg_pos"			=> "left top",
		"el_class"			=> ""
	), $atts));
	$out = "";
	$url 				= esc_url( $url );
	$offer 				= wp_kses( $offer, array( "small" => array() ) );
	$icon				= esc_html( $icon );
	$customize_colors	= (bool)$customize_colors;
	$bg_color			= esc_html( $bg_color );
	$font_color			= esc_html( $font_color );
	$icon_color			= esc_html( $icon_color );
	$use_bg_img			= (bool)$use_bg_img;
	$bg_img				= esc_html( $bg_img );
	$bg_size			= esc_html( $bg_size );
	$bg_repeat			= esc_html( $bg_repeat );
	$bg_pos				= esc_html( $bg_pos );
	$el_class			= esc_attr( $el_class );
	$banner_id 			= uniqid( "banner_id_" );
	if ( empty( $title ) && empty( $offer ) && empty( $icon ) ){
		return $out;
	}
	$classes 	= "prospect_banner" . ( empty( $url ) ? " prospect_module" : "" );
	$classes    .= !empty( $icon ) ? " icon_{$icon_pos}" : "";
	$classes	.= !empty( $el_class ) ? " $el_class" : "";
	$tag = "a";
	/* section styles */
	ob_start();
	if ( $customize_colors ){
		echo !empty( $font_color ) 	? " color: $font_color;" : ""; 
		echo !empty( $bg_color ) 	? " background-color: $bg_color;" : ""; 
	}
	if ( $use_bg_img && !empty( $bg_img ) ){
		$thumbnail  = wp_get_attachment_url( $bg_img );
		echo "background-image: 	url($thumbnail);"; 
		echo "background-size: 		$bg_size;"; 
		echo "background-repeat: 	$bg_repeat;"; 
		echo "background-position: 	$bg_pos;"; 
	}
	$section_styles = ob_get_clean();
	/* \section styles */
	/* icon styles */
	ob_start();
	if ( $customize_colors ){
		echo !empty( $font_color ) ? " color: $icon_color;" : ""; 
	}
	$icon_styles = ob_get_clean();
	/* \icon styles */
	$out .= !empty( $url ) ? "<a class='banner_link prospect_module' href='$url'>" : "";
		$out .= "<span id='$banner_id' class='$classes'" . ( !empty( $section_styles ) ? " style='$section_styles'" : "" ) . ">";
			$out .= "<span class='banner_wrapper clearfix'>";
				$out .= !empty( $icon )	 ? "<span class='banner_icon'" . ( !empty( $icon_styles ) ? " style='$icon_styles'" : "" ) . "><i class='fa fa-$icon'></i></span>" : "";
				$out .= !empty( $offer ) ? "<span class='banner_offer'>$offer</span>" : "";
				$out .= !empty( $title ) ? "<span class='banner_title'>$title</span>" : "";
			$out .= "</span>";
		$out .= "</span>";
	$out .= !empty( $url ) ? "</a>" : "";
	return $out;
}
add_shortcode( 'cws_sc_banner', 'prospect_sc_banner' );

function prospect_sc_call_to_action ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"title"				=> "",
		"text"				=> "",
		"icon"				=> "",
		'add_button'		=> '',
		'button_text'		=> '',
		'button_url'		=> '',
		'button_new_tab'	=> '',
		'button_size'		=> 'regular',
		"button_icon"		=> "",
		"button_icon_pos"	=> "left",
		"customize_colors"	=> "",
		"bg_color"			=> PROSPECT_THEME_FOOTER_BG_COLOR,
		"font_color"		=> "#fff",
		"icon_color"		=> PROSPECT_THEME_2_COLOR,
		"use_bg_img"		=> "",
		"bg_img"			=> "",
		"bg_size"			=> "auto",
		"bg_repeat"			=> "repeat",
		"bg_pos"			=> "left top",
		"color_over_img"	=> "",
		"el_class"			=> ""
	), $atts));
	$out = "";
	$text 				= esc_html( $text );
	$icon				= esc_html( $icon );
 	$add_button 		= (bool)$add_button;
	$customize_colors	= (bool)$customize_colors;
	$bg_color			= esc_html( $bg_color );
	$font_color			= esc_html( $font_color );
	$icon_color			= esc_html( $icon_color );
	$use_bg_img			= (bool)$use_bg_img;
	$bg_img				= esc_html( $bg_img );
	$bg_size			= esc_html( $bg_size );
	$bg_repeat			= esc_html( $bg_repeat );
	$bg_pos				= esc_html( $bg_pos );
	$color_over_img 	= (bool)$color_over_img;
	$el_class			= esc_attr( $el_class );
	$cta_id 			= uniqid( "cta_id_" );
	if ( empty( $title ) && empty( $offer ) && empty( $icon ) ){
		return $out;
	}
	$classes 	= "prospect_cta prospect_module";
	$classes	.= !empty( $el_class ) ? " $el_class" : "";
	$tag = "a";
	/* section styles */
	ob_start();
	if ( $customize_colors ){
		echo !empty( $font_color ) 	? " color: $font_color;" : ""; 
	}
	$section_styles = ob_get_clean();
	/* \section styles */
	/* color layer styles */
	ob_start();
	if ( $customize_colors ){
		echo !empty( $bg_color ) 	? " background-color: $bg_color;" : ""; 
	}
	$color_layer_styles = ob_get_clean();
	/* \color layer styles */
	/* img layer styles */
	ob_start();
	if ( $use_bg_img && !empty( $bg_img ) ){
		$thumbnail  = wp_get_attachment_url( $bg_img );
		echo "background-image: 	url($thumbnail);"; 
		echo "background-size: 		$bg_size;"; 
		echo "background-repeat: 	$bg_repeat;"; 
		echo "background-position: 	$bg_pos;"; 
	}
	$img_layer_styles = ob_get_clean();
	/* \img layer styles */
	/* icon styles */
	ob_start();
	if ( $customize_colors ){
		echo !empty( $font_color ) ? " color: $icon_color;" : ""; 
		echo !empty( $font_color ) ? " border-color: $icon_color;" : ""; 
	}
	$icon_styles = ob_get_clean();
	/* \icon styles */
	$color_layer = !empty( $color_layer_styles ) ? "<div class='cta_bg_layer color_layer' style='$color_layer_styles'></div>" : "";
	$img_layer = !empty( $img_layer_styles ) ? "<div class='cta_bg_layer img_layer' style='$img_layer_styles'></div>" : "";
	$button_atts = array(
		'title'		=> $button_text,
		'url'		=> $button_url,
		'new_tab'	=> $button_new_tab,
		'size'		=> $button_size,
		'icon'		=> $button_icon,
		'icon_pos'	=> $button_icon_pos
	);
	if ( $customize_colors ){
		$button_atts['customize_colors'] 	= true;
		$button_atts['custom_color'] 		= $icon_color;
		$button_atts['font_color'] 			= $font_color;
	}
	$button = $add_button ? prospect_sc_button( $button_atts ) : "";
	$text_content = "";
	$text_content .= !empty( $title ) ? "<h3 class='cta_title'>$title</h3>" : "";			
	$text_content .= !empty( $text ) ? "<div class='cta_text'>$text</div>" : "";
	$out .= "<div id='$cta_id' class='$classes'" . ( !empty( $section_styles ) ? " style='$section_styles'" : "" ) . ">";
		if ( $color_over_img ){
			$out .= !empty( $img_layer ) ? $img_layer : "";
			$out .= !empty( $color_layer ) ? $color_layer : "";			
		}
		else{
			$out .= !empty( $color_layer ) ? $color_layer : "";
			$out .= !empty( $img_layer ) ? $img_layer : "";
		}
		$out .= "<div class='cta_holder'>";
			$out .= !empty( $icon )	 ? "<div class='cta_icon'" . ( !empty( $icon_styles ) ? " style='$icon_styles'" : "" ) . "><i class='fa fa-$icon'></i></div>" : "";
			$out .= !empty( $text_content ) ? "<div class='cta_content'>$text_content</div>" : "";
			$out .= !empty( $button ) ? "<div class='cta_button'>$button</div>" : "";
		$out .= "</div>";
	$out .= "</div>";
	return $out;
}
add_shortcode( 'cws_sc_call_to_action', 'prospect_sc_call_to_action' );

function prospect_sc_progress_bar ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		'title'				=> '',
		'progress'			=> '',
		'use_custom_color'	=> '',
		'custom_fill_color'	=> '',
		'custom_title_color'=> '',
		'el_class'			=> ''
	), $atts));
	$title 				= esc_html( $title );
	$progress 			= esc_html( $progress );
	$use_custom_color 	= (bool)$use_custom_color;
	$custom_fill_color 	= esc_attr( $custom_fill_color );
	$custom_title_color = esc_attr( $custom_title_color );
	$el_class			= esc_attr( $el_class );
	$out = "";
	if ( empty( $progress ) || !is_numeric( $progress ) ) return $out;
	$out .= "<div class='prospect_pb prospect_module" . ( !empty( $el_class ) ? " $el_class" : "" ) . "'>";
		$out .= !empty( $title ) ? "<h6 class='prospect_pb_title' " . ( $use_custom_color && !empty( $custom_title_color ) ? "style='color: $custom_title_color;'" : "" ) . ">$title</h6>" : "";
		$out .= "<div class='prospect_pb_bar'>";
			$out .= "<div class='prospect_pb_progress' data-value='$progress' style='width:0%;" . ( $use_custom_color && !empty( $custom_fill_color ) ? "background-color: $custom_fill_color;" : "" ) . "'>";
			$out .= "</div>";
		$out .= "</div>";
	$out .= "</div>";
	return $out;
}
add_shortcode( 'cws_sc_progress_bar', 'prospect_sc_progress_bar' );

function prospect_sc_milestone ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"icon_lib"					=> "",
		'number'					=> '',
		'use_custom_number_color'	=> '',
		'custom_number_color'		=> PROSPECT_THEME_COLOR,
		'title'						=> '',
		'speed'						=> '',
		'alt'						=> '',
		'use_custom_color'			=> '',
		'custom_color'				=> '',
		'custom_title_color'		=> '',
		'title_size'				=> '',
		'el_class'					=> ''
	), $atts));
	$icon_lib 					= esc_attr( $icon_lib );
	$icon 						= prospect_vc_sc_get_icon( $atts );
	$icon 						= esc_attr( $icon );
	$number						= esc_html( $number );
	$use_custom_number_color 	= (bool)$use_custom_number_color;
	$custom_number_color 		= esc_attr( $custom_number_color );
	$title 						= esc_html( $title );
	$speed						= esc_html( $speed );
	$alt 						= (bool)$alt;
	$use_custom_color 			= (bool)$use_custom_color;
	$custom_color 				= esc_attr( $custom_color );
	$custom_title_color 		= esc_attr( $custom_title_color );
	$title_size 				= esc_html( $title_size );
	$el_class					= esc_attr( $el_class );
	$out = "";
	if ( empty( $number ) || !is_numeric( $number ) ) return $out;
	wp_enqueue_script( 'odometer' );
	$title_font_size = !empty($title_size) ? $title_size : "";
	$out .= "<div class='prospect_milestone prospect_module" . ( !empty( $el_class ) ? " $el_class" : "" ) . ( $alt ? " milestone-alt" : "" ) . "'" . ">";
		$out .= "<div class='prospect_milestone_background'>" . prospect_figure_style( $custom_color , $alt ) . "</div>";
		$out .= "<div class='prospect_milestone_content'>";
			$out .= !empty( $icon ) ? "<div class='prospect_milestone_icon'" . ( $use_custom_color && !empty( $custom_color ) && !$alt ? " style=' color: $custom_color;'" : "" ) . "><i class='fa $icon'></i></div>" : "";
			$out .= "<div class='prospect_milestone_number'" . ( !empty( $speed ) && is_numeric( $speed ) ? " data-speed='$speed'" : "" ) . " " . ( $use_custom_number_color && !empty( $custom_number_color ) ? "style=' color: $custom_number_color;'" : "" ) . ">$number</div>";
			$out .= !empty( $title ) ? "<h6 class='prospect_milestone_title' " . (!empty( $custom_title_color ) ? " style=' color: $custom_title_color; font-size: " . $title_font_size . "px'" : "") . ">$title</h6>" : "";
		$out .= "</div>";	
	$out .= "</div>";
	return $out;
}
add_shortcode( 'cws_sc_milestone', 'prospect_sc_milestone' );

function prospect_sc_services ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		'title'						=> '',
		'icon_lib'					=> '',
		'add_button'				=> '',
		'add_hover'					=> '',
		'button_text'				=> '',
		'button_url'				=> '',
		'button_new_tab'			=> '',
		'button_size'				=> 'regular',
		'icon_pos'					=> 'icon_center',
		'icon_size'					=> 'small',
		'button_fw'					=> '',
		'customize_colors'			=> '',
		'font_color'				=> PROSPECT_THEME_COLOR,
		'background_color'			=> 'transparent',
		'stroke_color'				=> PROSPECT_THEME_COLOR,
		'font_color_hover'			=> '#ffffff',
		'background_color_hover'	=> PROSPECT_THEME_COLOR,
		'stroke_color_hover'		=> PROSPECT_THEME_COLOR,
		'el_class'					=> ''
	), $atts));
	$title 						= esc_html( $title );
	$icon_lib 					= esc_attr( $icon_lib );
	$icon 						= prospect_vc_sc_get_icon( $atts );
	$icon 						= esc_attr( $icon );
	$desc 						= apply_filters( 'the_content', $content );
	$icon_pos 					= esc_html( $icon_pos );
	$icon_size 					= esc_html( $icon_size );
	$add_button 				= (bool)$add_button;
	$add_hover 					= (bool)$add_hover;
	$customize_colors 			= (bool)$customize_colors;
	$font_color 				= esc_attr( $font_color );
	$background_color 			= esc_attr( $background_color );
	$stroke_color 				= esc_attr( $stroke_color );
	$font_color_hover 			= esc_attr( $font_color_hover );
	$background_color_hover 	= esc_attr( $background_color_hover );
	$stroke_color_hover 		= esc_attr( $stroke_color_hover );
	$el_class					= esc_attr( $el_class );
	$out = "";
	if ( function_exists( 'vc_icon_element_fonts_enqueue' ) ){
		vc_icon_element_fonts_enqueue( $icon_lib );		
	}
	$button_atts = array(
		'title'		=> $button_text,
		'url'		=> $button_url,
		'new_tab'	=> $button_new_tab,
		'size'		=> $button_size,
		'fw'		=> $button_fw,
	);
	if ( $customize_colors ){
		$button_atts['customize_colors'] 	= true;
		$button_atts['custom_color'] 		= $font_color;
	}
	$section_id = uniqid( 'prospect_services_column_' );
	$button = $add_button ? prospect_sc_button( $button_atts ) : "";
	$title_part = $desc_part = "";
	$title_part .= !empty( $title ) ? "<h3 class='prospect_services_title'>$title</h3>" : "";
	$title_part .= !empty( $icon ) ? "<div class='prospect_services_icon'><div class='icon $icon'>" . prospect_figure_style( ) . "</div></div>" : "";
	$desc_part .= !empty( $desc ) ? "<div class='prospect_services_desc clearfix'>$desc</div>" : "";
	/* styles */
	ob_start();
	if ( $customize_colors && !empty( $font_color ) && !empty( $stroke_color ) ){
	echo "#$section_id .prospect_services_title,
			#$section_id .prospect_services_icon .icon{
				color: $font_color;
			}
			#$section_id .prospect_services_icon svg{
				fill: $background_color;
				stroke: $stroke_color;
			}
			#$section_id.hovered:hover .prospect_services_icon .icon{
				color: $font_color_hover;
			}
			#$section_id.hovered:hover .prospect_services_icon svg{
				fill: $background_color_hover;
				stroke: $stroke_color_hover;
			}
			#$section_id.icon_center .prospect_services_desc .widgettitle:before{
				background: $font_color;
			}";
	}
	/* \styles */
	$classes = $add_hover ? " hovered " : "";
	$classes .= $icon_size . " " . $icon_pos;
	$styles = ob_get_clean();
	$styles = json_encode($styles);

	$out .= "<div id='$section_id' data-style='".esc_attr($styles)."' class='prospect_services_column prospect_module render_styles " . $classes . ( !empty( $button ) ? " prospect_flex_column_sb" : "" ) . ( !empty( $el_class ) ? " $el_class" : "" ) . "'>";
		if ( !empty( $title_part ) && !empty( $desc_part ) ){
			$out .= "<div class='prospect_services_data'>";
				$out .= $title_part;
				$out .= $desc_part;
			$out .= "</div>";
			$out .= !empty( $button ) ? "<div class='prospect_services_button'>$button</div>" : "";
		}
		else{
			$out .= "<div class='prospect_services_data'>";
				$out .= $title_part;
				$out .= $desc_part;
			$out .= "</div>";
			$out .= !empty( $button ) ? "<div class='prospect_services_button'>$button</div>" : "";
		}
	$out .= "</div>";
	return $out;
}
add_shortcode( 'cws_sc_services', 'prospect_sc_services' );

function prospect_sc_vc_testimonial ( $atts = array(), $content = "" ){
	$atts['thumbnail'] = isset( $atts['thumbnail'] ) && !empty( $atts['thumbnail'] ) ? wp_get_attachment_url( $atts['thumbnail'] ) : "";
	return prospect_testimonial_renderer( $atts, $content );
}
add_shortcode( 'cws_sc_vc_testimonial', 'prospect_sc_vc_testimonial' );
function prospect_sc_testimonial ( $atts = array(), $content = "" ){
	if ( !empty( $atts['thumbnail'] ) ){
		$thumbnail_data = json_decode( $atts['thumbnail'], true );
		$atts['thumbnail'] = ( isset( $thumbnail_data['@'] ) && isset( $thumbnail_data['@']['src'] ) ) ? $thumbnail_data['@']['src'] : "";
	}
	return function_exists( 'prospect_testimonial_renderer' ) ? prospect_testimonial_renderer( $atts, $content ) : '';
}
add_shortcode( 'cws_sc_testimonial', 'prospect_sc_testimonial' );

function prospect_sc_pricing_plan ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		'title'				=> '',
		'currency'			=> '',
		'price'				=> '29.00',
		'price_desc'		=> '',
		'add_button'		=> '',
		'button_text'		=> '',
		'button_url'		=> '',
		'button_new_tab'	=> '',
		'button_size'		=> 'regular',
		'button_alt'		=> '',
		'button_fw'			=> '',
		'highlighted'		=> '',
		'use_custom_color'	=> '',
		'custom_color'		=> PROSPECT_THEME_COLOR,
		'el_class'			=> ''
 	), $atts));
 	$title 				= esc_html( $title );
 	$currency 			= esc_html( $currency );
 	$price 				= esc_html( $price );
 	$price_desc 		= esc_html( $price_desc );
 	$add_button 		= (bool)$add_button;
 	$highlighted		= (bool)$highlighted;
 	$use_custom_color 	= (bool)$use_custom_color;
	$button_alt 		= (bool)$button_alt;
 	$custom_color 		= esc_attr( $custom_color );
 	$el_class			= esc_attr( $el_class );
 	$out = "";
	$section_id = uniqid( 'prospect_pricing_plan_' );
 	ob_start();
 	echo !empty( $title ) ? "<h3 class='pricing_plan_title'>$title</h3>" : "";
 	if ( !empty( $price ) ){
		preg_match( "/(\.| |,)(\d+)$/", $price, $matches );
		$fract_price_part = isset( $matches[0] ) ? $matches[0] : '';
		$main_price_part = !empty( $fract_price_part ) ? esc_html( substr( $price, 0, strpos( $price, $fract_price_part ) ) ) : esc_html( $price );
		$fract_price_part = !empty( $matches[2] ) ? $matches[2] : "00";
 		echo "<div class='pricing_plan_price'>";
 			echo !empty( $currency ) ? "<span class='currency'>$currency</span>" : "";
 			echo "<span class='main_price_part'>$main_price_part</span>";
 			echo "<span class='fract_price_part'>$fract_price_part</span>";
 			echo !empty( $price_desc ) ? "<span class='price_desc'>$price_desc</span>" : "";
 		echo "</div>";
 	}
	$content = apply_filters( 'the_content', $content );
	echo !empty( $content ) ? "<div class='pricing_plan_content'>$content</div>" : "";
 	$plan = ob_get_clean();
	$button_atts = array(
		'title'		=> $button_text,
		'url'		=> $button_url,
		'new_tab'	=> $button_new_tab,
		'size'		=> $button_size,
		'alt'		=> $button_alt,
		'fw'		=> $button_fw
	);
	if ( $use_custom_color ){
		$button_atts['customize_colors'] = true;
		$button_atts['custom_color'] = $custom_color;
	}
	$button = $add_button ? prospect_sc_button( $button_atts ) : "";
	/* styles */
	$styles = "#$section_id .pricing_plan_title{
		background-color: $custom_color;
	}
	#$section_id .pricing_plan_content ul li:before{
		color: $custom_color;
	}";
	$styles = json_encode($styles);
	/* \styles */
	$section_class = "prospect_pricing_plan prospect_module render_styles";
	$section_class .= !empty( $plan ) && !empty( $button ) ? " prospect_flex_column_sb" : "";
	$section_class .= $highlighted ? " highlighted" : "";
	$section_class .= !empty( $el_class ) ? " $el_class" : "";
	$out .= "<div id='$section_id' data-style='".esc_attr($styles)."' class='$section_class'>";
		$out .= !empty( $plan ) ? "<div class='pricing_plan'>$plan</div>" : "";
		$out .= !empty( $button ) ? "<div class='pricing_plan_button'>$button</div>" : "";
	$out .= "</div>";
	return $out;
}
add_shortcode( 'cws_sc_pricing_plan', 'prospect_sc_pricing_plan' );

function prospect_sc_divider ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"type"				=> "",
		"mtop"				=> "",
		"mbottom"			=> "",
		"customize_colors"	=> false,
		"first_color"		=> PROSPECT_THEME_COLOR,
		"second_color"		=> PROSPECT_THEME_2_COLOR,
		"third_color"		=> PROSPECT_THEME_3_COLOR,
		"el_class"			=> ""
 	), $atts));
 	$type 			= esc_attr( $type );
  	$mtop 			= esc_attr( $mtop );
  	$mbottom 		= esc_attr( $mbottom );
  	$first_color 	= esc_attr( $first_color );
 	$second_color 	= esc_attr( $second_color );
 	$third_color 	= esc_attr( $third_color );
 	$el_class		= esc_attr( $el_class );
	$classes = "";
	$classes .= !empty( $type ) ? " $type" : "";
	$classes .= !empty( $el_class ) ? " $el_class" : "";
	$classes = trim( $classes );
	ob_start();
	if ( !empty($mtop) ){
		echo "margin-top: {$mtop}px; ";
	}
	if ( !empty($mbottom) ){
		echo "margin-bottom: {$mbottom}px; ";
	}
	$spacing_styles = ob_get_clean();
	ob_start();
	if ( $customize_colors ){
		if ( !empty($first_color ) ){
			echo "background-color: $first_color; ";
		}
	}
	$color_styles = ob_get_clean();
	$out = "";
	$out .= "<hr style='" . $spacing_styles . $color_styles . "'" . ( !empty( $classes ) ? " class='$classes'" : "" ) . " />";
	return $out;
}
add_shortcode( 'cws_sc_divider', 'prospect_sc_divider' );

function prospect_sc_spacing ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"spacing"			=> "30px",
		"el_class"			=> ""
 	), $atts));
 	$spacing = esc_attr( $spacing );
 	$el_class = esc_attr( $el_class );
 	$out = "";
 	if ( !empty( $spacing ) ){
 		$out .= "<div class='cws_spacing" . ( !empty( $el_class ) ? " $el_class" : "" ) . "' style='height: $spacing;'></div>";
 	}
	return $out;
}
add_shortcode( 'cws_sc_spacing', 'prospect_sc_spacing' );

function prospect_sc_twitter ( $atts = array(), $content = "" ){
	extract( shortcode_atts( array(
		"icon"						=> "",
		"twitt_align"				=> "center",
		'number' 					=> 4,
		'visible_number' 			=> 2,
		"customize_colors"			=> false,
		"custom_font_color"			=> "",
		"el_class"					=> ""
 	), $atts));
 	$title 					= esc_attr( $icon );
 	$twitt_align 			= esc_attr( $twitt_align );
 	$title 					= esc_html( $title );
  	$number 				= esc_textarea( $number );
  	$visible_number 		= esc_textarea( $visible_number );
  	$customize_colors 		= (bool)$customize_colors;
  	$custom_font_color 	  	= esc_attr( $custom_font_color );
 	$el_class				= esc_attr( $el_class );
 	$number = empty( $number ) ? 4 : (int)$number;
 	$visible_number = empty( $visible_number ) ? 2 : (int)$visible_number;
	$classes = "cws_twitter prospect_module";
	$classes .= !empty( $el_class ) ? " $el_class" : "";
	$classes = trim( $classes );
	$id = uniqid( "cws_twitter_" );
	$number = (int)$number;
	$visible_number = (int)$visible_number;
	$visible_number = $visible_number == 0 ? $number : $visible_number;
	$retrieved_tweets_number = 0;
	$is_plugin_installed = function_exists( 'getTweets' );
	$tweets = $is_plugin_installed ? getTweets( $number ) : array();
	$retrieved_tweets_number = count( $tweets );
	$is_carousel = $retrieved_tweets_number > $visible_number;
	if ( $is_carousel ){
		wp_enqueue_script( 'owl_carousel' );
	}
	$tweets_received = false;
	ob_start();
	if ( !empty( $tweets ) ){
		if ( isset( $tweets['error'] ) && !empty( $tweets['error'] ) ){
			echo do_shortcode( "[cws_sc_msg_box title='" . esc_html__( 'Twitter applyed with error', 'prospect-shortcodes' ) . "' type='error']" . esc_html( $tweets['error'] ) . "[/cws_sc_msg_box]" );
		}
		else{
			if ( $is_carousel ){
				echo "<ul class='cws_tweets widget_carousel bullets_nav'>";
				$groups_count = ceil( $retrieved_tweets_number / $visible_number );
					for ( $i = 0; $i < $groups_count; $i++ ){
						echo "<li>";
							echo "<ul>";
								for( $j = $i * $visible_number; ( ( $j < ( $i + 1 ) * $visible_number ) && ( $j < $retrieved_tweets_number ) ); $j++ ){
									$tweet = $tweets[$j];
									$tweet_text = isset( $tweet['text'] ) ? $tweet['text'] : "";
									$tweet_entitties = isset( $tweet['entities'] ) ? $tweet['entities'] : array();
									$tweet_urls = isset( $tweet_entitties['urls'] ) && is_array( $tweet_entitties['urls'] ) ? $tweet_entitties['urls'] : array();
									foreach ( $tweet_urls as $tweet_url ) {
										$display_url = isset( $tweet_url['display_url'] ) ? $tweet_url['display_url'] : "";
										$received_url = isset( $tweet_url['url'] ) ? $tweet_url['url'] : "";
										$html_url = "<a href='$received_url'>$display_url</a>";
										$tweet_text = substr_replace( $tweet_text, $html_url, strpos( $tweet_text, $received_url ), strlen( $received_url ) );
									}
									$tweet_date = $tweet['created_at'];
									echo "<li class='tweet'>";
										echo "<div class='text'>" . $tweet_text . "</div>";
										echo "<div class='date'>";
											echo esc_html( date( "Y-m-d H:i:s", strtotime( $tweet_date ) ) );
										echo "</div>";	
									echo "</li>";						
								}
							echo "</ul>";
						echo "</li>";
					}
				echo "</ul>";
			}
			else{
				echo "<ul class='cws_tweets'>";
					foreach ( $tweets as $tweet ) {
						echo "<li class='tweet'>";
							$tweet_text = isset( $tweet['text'] ) ? $tweet['text'] : "";
							$tweet_entitties = isset( $tweet['entities'] ) ? $tweet['entities'] : array();
							$tweet_urls = isset( $tweet_entitties['urls'] ) && is_array( $tweet_entitties['urls'] ) ? $tweet_entitties['urls'] : array();
							foreach ( $tweet_urls as $tweet_url ) {
								$display_url = isset( $tweet_url['display_url'] ) ? $tweet_url['display_url'] : "";
								$received_url = isset( $tweet_url['url'] ) ? $tweet_url['url'] : "";
								$html_url = "<a href='$received_url'>$display_url</a>";
								$tweet_text = substr_replace( $tweet_text, $html_url, strpos( $tweet_text, $received_url ), strlen( $received_url ) );
							}
							$tweet_date = $tweet['created_at'];
							echo "<div class='text'>" . $tweet_text . "</div>";
							echo "<div class='date'>";
								echo esc_html( date( "Y-m-d H:i:s", strtotime( $tweet_date ) ) );
							echo "</div>";
						echo "</li>";
					}
				echo "</ul>";
			}
			$tweets_received = true;
		}
	}
	else{
		if ( !$is_plugin_installed ){
			echo do_shortcode( "[cws_sc_msg_box title='" . esc_html__( 'Plugin not installed', 'prospect-shortcodes' ) . "' type='warn']" . esc_html__( 'Please install and activate required plugin ', 'prospect-shortcodes' ) . "<a href='https://ru.wordpress.org/plugins/oauth-twitter-feed-for-developers/'>" . esc_html__( "oAuth Twitter Feed for Developers", 'prospect-shortcodes' ) . "</a>[/cws_sc_msg_box]" );
		}
	}
	$twitter_response = ob_get_clean();


	ob_start();
	if ( $customize_colors && !empty( $custom_font_color ) ){
		echo "#{$id} .cws_twitter_icon i,
				#{$id} .cws_tweets .tweet a{
					color: $custom_font_color;
				}
				#{$id} .cws_twitter_icon i,
				#{$id} .owl-pagination .owl-page{
					border-color: $custom_font_color;
				}
				#{$id} .owl-pagination .owl-page.active{
					background-color: $custom_font_color;
				}";
	}
	$styles = ob_get_clean();

	ob_start();
	if ( $tweets_received ){
		echo !empty( $styles ) ? "<style type='text/css'>$styles</style>" : "";
		echo "<div id='$id' class='$classes' style='text-align:" . $twitt_align . "'>";
			if ( !empty( $icon ) ){
				echo "<div class='cws_twitter_icon'>";
					echo "<i class='$icon'></i>";
				echo "</div>";
			}
			echo $twitter_response;
		echo "</div>";
	}
	else{
		echo $twitter_response;
	}
	$out = ob_get_clean();
	return $out;
}
add_shortcode( 'cws_sc_twitter', 'prospect_sc_twitter' );

if ( function_exists( 'vc_add_shortcode_param' ) ) {
	vc_add_shortcode_param( 'cws_dropdown' , 'prospect_vc_dropdown_field' );
}


?>